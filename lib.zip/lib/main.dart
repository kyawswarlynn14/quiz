import 'package:flutter/material.dart';
import 'package:quiz/quiz.dart';

void main() {
  runApp(
    const Quiz()
  );
}